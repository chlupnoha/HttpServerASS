package handlers;


import server.HttpExchanger;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chlupnoha
 */
public interface Handler {
    
    public void handle(HttpExchanger httpRequest);
    
}
